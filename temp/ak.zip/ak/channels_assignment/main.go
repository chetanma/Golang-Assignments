package main

import (
	"encoding/json"
	"io/ioutil"
)


type UpdateLevelFilter  func(c *Customer,ch chan Customer)
type BonusFilter  func(c *Customer,ch chan Customer)
func main() {

	ch := GenerateCustomers()

	MyChangeLevelFilter := func(c *Customer,ch chan Customer)  {
		if c.Points > 800 && c.Points < 1500 {
			c.Level = Gold
			ch <- *c
		}
		if c.Points > 1500 {
			c.Level = Platinum
			ch <- *c
		}
	}

	MyBonusFilter := func(c *Customer,ch chan Customer) {
		if c.Level == Gold {
			c.Points = c.Points + 75
			ch <- *c
		}
		if c.Level == Platinum {
			c.Points = c.Points + 150
			ch <- *c
		}
	}

	out := UpgradeLevelWorker(ch,MyChangeLevelFilter)
	out2 := UpgradeLevelWorker(ch,MyChangeLevelFilter)

	m1 := Merge(out, out2)

	n1 := BonusPointsWorker(m1,MyBonusFilter)
	n2 := BonusPointsWorker(m1,MyBonusFilter)

	m2 := Merge(n1, n2)

	

	StoreToJsonFile(m2, "data.json")

	
	
	

}



func GenerateCustomers() <-chan Customer {
	ch := make(chan Customer)
	go func() {
		defer close(ch)
		cust1, _ := NewCustomer("AA", 1001, 1250, Silver)
		cust2, _ := NewCustomer("AA", 1002, 900, Silver)
		cust3, _ := NewCustomer("AA", 1003, 410, Silver)
		cust4, _ := NewCustomer("AA", 1004, 1700, Silver)
		
		ch <- *cust1
		ch <- *cust2
		ch <- *cust3
		ch <- *cust4


	}()
	return ch
}

func UpgradeLevelWorker(cust <-chan Customer,f  UpdateLevelFilter) <-chan Customer {
	ch := make(chan Customer)

	go func() {
		defer close(ch)
		for {
			c, ok := <-cust
			if ok {
				f(&c,ch)

				
			} else {
				break
			}

		}
		

	}()

	return ch
}

func Merge(ch1, ch2 <-chan Customer) <-chan Customer {
	ch := make(chan Customer)

	go func() {
		defer close(ch)
		for ch1 != nil || ch2 != nil {
			select {
			case cust, ok := <-ch1:
				if ok {
					//fmt.Println(cust)
					ch <- cust
				} else {
					ch1 = nil
				}

			case cust, ok := <-ch2:
				if ok {
					// fmt.Println(cust)
					ch <- cust
				} else {
					ch2 = nil
				}
			}
			
		}

		

	}()

	return ch
}

func BonusPointsWorker(cust <-chan Customer, f BonusFilter) <-chan Customer {
	ch := make(chan Customer)

	go func() {
		defer close(ch)
		for {
			c, ok := <-cust
			if ok {
				f(&c,ch)
			} else {
				break
			}

		}
		

	}()
	return ch
}

func StoreToJsonFile(c <-chan Customer, file string) {


		customers := make([]Customer,0,10)

		for {
			cust, ok := <- c
			if ok {
				customers = append(customers, cust)
				
				
				//fmt.Println(ioerr)
				

			} else {
				data, _ := json.Marshal(customers)

				ioutil.WriteFile(file, data,0644)
				break
			}

		}
		
	
}
//, 0644