package main

import (
	"encoding/json"
	"io/ioutil"
)

type Auth struct {
	Username string
	Password string
	IsAdmin bool 
}

type AuthStore struct {
	Data []Auth
}

func NewAuthStore() AuthStore {
	return AuthStore{
		Data: make([]Auth,0,100),
	}
}

func (repo *AuthStore) LoadFromFile(file string) {
	data, _ := ioutil.ReadFile(file)

	json.Unmarshal(data, &repo.Data)

}