package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
)

type Hotel struct {
	Id           int
	Name         string
	Source       string
	Availability int
	RoomType     string
	Location     string
}

func NewHotel(name string, id int, loc string) *Hotel {
	return &Hotel{
		Name:     name,
		Id:       id,
		Location: loc,
	}
}

type HotelStore interface {
	GetHotel(id int) *Hotel
	GetHotels() []Hotel
	AddHotel(h Hotel)
	UpdateHotel(id int, h Hotel) bool
	DeleteHotel(id int) bool
}

type HotelsDataStore struct {
	Data []Hotel
}

func NewHotelsDataStore() HotelsDataStore {
	return HotelsDataStore{
		Data: make([]Hotel, 0, 100),
	}
}

func (hd *HotelsDataStore) AddHotel(h Hotel) {
	hd.Data = append(hd.Data, h)
	hd.StoreTofile("data.json")
}

func (hd *HotelsDataStore) GetHotel(id int) *Hotel {
	hd.LoadFromFile("data.json")
	for _, v := range hd.Data {
		if v.Id == id {
			return &v
		}
	}
	return nil
}

func (hd *HotelsDataStore) GetHotels() []Hotel {
	hd.LoadFromFile("data.json")
	return hd.Data
}

func (hd *HotelsDataStore) UpdateHotel(id int, h Hotel) bool {

	for i, _ := range hd.Data {
		if hd.Data[i].Id == id {

			hd.Data[i].Name = h.Name
			hd.Data[i].Location = h.Location
			hd.Data[i].Availability = h.Availability
			hd.Data[i].Source = h.Source
			hd.Data[i].RoomType = h.RoomType
			hd.StoreTofile("data.json")

			return true
		}
	}

	return false
}

func (hd *HotelsDataStore) DeleteHotel(id int) bool {
	NewData := make([]Hotel, 0, 100)

	found := false

	for i, _ := range hd.Data {
		if hd.Data[i].Id == id {
			found = true
			continue
		} else {
			NewData = append(NewData, hd.Data[i])
		}

	}
	hd.Data = NewData
	hd.StoreTofile("data.json")

	return found
}

func (repo *HotelsDataStore) StoreTofile(file string) error {
	data, err := json.Marshal(repo.Data)
	if err != nil {
		fmt.Println(err)
		return err
	}

	ioerr := ioutil.WriteFile(file, data, 0644)
	if ioerr != nil {
		fmt.Println(ioerr)
		return ioerr
	}

	return nil
}

func (repo *HotelsDataStore) LoadFromFile(file string) {
	data, _ := ioutil.ReadFile(file)

	json.Unmarshal(data, &repo.Data)

}
