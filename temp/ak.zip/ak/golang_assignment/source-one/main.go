package main

import (
	"encoding/json"
	"fmt"
	"github.com/gorilla/mux"
	"io/ioutil"
	"net/http"
	"strconv"
	"context"
)

func GetHotels(store HotelStore) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		data := store.GetHotels()
		w.WriteHeader(http.StatusOK)
		dataBytes, _ := json.Marshal(data)
		fmt.Fprint(w, string(dataBytes))
	}
}

func GetHotel(store HotelStore) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		params := mux.Vars(r)
		idStr := params["id"]
		id, _ := strconv.Atoi(idStr)
		hotel := store.GetHotel(id)
		if hotel != nil {
			w.WriteHeader(http.StatusOK)
			hotelBytes, _ := json.Marshal(hotel)
			fmt.Fprint(w, string(hotelBytes))
		} else {
			w.WriteHeader(http.StatusNoContent)
			// fmt.Fprint(w, "We couldn't find any hotel with entered id")
		}
	}
}

func CreateHotel(store HotelStore) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		isAdminCtx := ctx.Value("isAdmin")
		isAdmin := isAdminCtx.(bool)
		if !isAdmin {
			w.WriteHeader(http.StatusUnauthorized)
			// fmt.Fprint(w, "Not Authorized")
			return
		}
		w.Header().Set("Content-Type", "application/json")
		var h Hotel
		body, _ := ioutil.ReadAll(r.Body)
		json.Unmarshal(body, &h)
		store.AddHotel(h)
		w.WriteHeader(http.StatusOK)
		// fmt.Fprint(w, "Hotel added successfully!", h)
	}
}

func UpdateHotel(store HotelStore) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		isAdminCtx := ctx.Value("isAdmin")
		isAdmin := isAdminCtx.(bool)
		if !isAdmin {
			w.WriteHeader(http.StatusUnauthorized)
			// fmt.Fprint(w, "Not Authorized")
			return
		}
		w.Header().Set("Content-Type", "application/json")
		var h Hotel
		body, _ := ioutil.ReadAll(r.Body)
		json.Unmarshal(body, &h)
		params := mux.Vars(r)
		idStr := params["id"]
		id, _ := strconv.Atoi(idStr)
		found := store.UpdateHotel(id, h)
		if found == true {
			w.WriteHeader(http.StatusOK)
			// fmt.Fprint(w, "Hotel updated succesfully!")
		} else {
			w.WriteHeader(http.StatusNoContent)
			// fmt.Fprint(w, "We couldn't find any hotel with entered id")
		}

	}
}

func DeleteHotel(store HotelStore) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		isAdminCtx := ctx.Value("isAdmin")
		isAdmin := isAdminCtx.(bool)
		if !isAdmin {
			w.WriteHeader(http.StatusUnauthorized)
			// fmt.Fprint(w, "Not Authorized")
			return
		}
		w.Header().Set("Content-Type", "application/json")
		params := mux.Vars(r)
		idStr := params["id"]
		id, _ := strconv.Atoi(idStr)
		found := store.DeleteHotel(id)
		if found == true {
			w.WriteHeader(http.StatusOK)
			// fmt.Fprint(w, "Hotel deleted succesfully!")
		} else {
			w.WriteHeader(http.StatusNoContent)
			// fmt.Fprint(w, "We couldn't find any hotel with entered id")
		}
		
	}
}



func AuthCheck(user, pass string) (bool,bool) {
	aStore := NewAuthStore()
	aStore.LoadFromFile("users.json")

	//fmt.Println(aStore.Data)

	for _, v := range aStore.Data {
		if user == v.Username {
			if pass == v.Password {
				if v.IsAdmin == true {
					return true,true
				}
				return true,false
			}
		}
	}

	return false,false
}

func BasicAuthMiddleWare(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user, pass, ok := r.BasicAuth()
		verifiedUser,isAdmin := AuthCheck(user, pass)
		if !ok || !verifiedUser {
			w.WriteHeader(http.StatusUnauthorized)
			// fmt.Fprint(w, "Not Authorized")
			return
		}
		context := context.WithValue(r.Context(), "isAdmin", isAdmin )
		h(w, r.WithContext(context))
	}
}

func main() {

	hStore := NewHotelsDataStore()
	hStore.LoadFromFile("data.json")

	r := mux.NewRouter()
	r.HandleFunc("/hotels", BasicAuthMiddleWare(GetHotels(&hStore))).Methods("GET")
	r.HandleFunc("/hotels/{id}", BasicAuthMiddleWare(GetHotel(&hStore))).Methods("GET")
	r.HandleFunc("/hotels", BasicAuthMiddleWare(CreateHotel(&hStore))).Methods("POST")
	r.HandleFunc("/hotels/{id}", BasicAuthMiddleWare(UpdateHotel(&hStore))).Methods("PUT")
	r.HandleFunc("/hotels/{id}", BasicAuthMiddleWare(DeleteHotel(&hStore))).Methods("DELETE")
	http.ListenAndServe(":8081", r)
}
