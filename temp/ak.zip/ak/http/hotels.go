package main



//import "fmt"

type Hotel struct {
	Name     string
	Id       int
	Location string
}

func NewHotel(name string, id int, loc string) *Hotel {
	return &Hotel{
		Name:     name,
		Id:       id,
		Location: loc,
	}
}

type HotelStore interface {
	GetHotel(id int) *Hotel
	GetHotels() []Hotel
	AddHotel(h Hotel)
	UpdateHotel(id int, h Hotel) bool
	//DeleteHotel(id int) bool
}

type HotelsDataStore struct {
	Data []Hotel
}

func NewHotelsDataStore() HotelsDataStore {
	return HotelsDataStore{
		Data: make([]Hotel, 0, 100),
	}
}

func (hd *HotelsDataStore) AddHotel(h Hotel) {
	hd.Data = append(hd.Data, h)
}

func (hd *HotelsDataStore) GetHotel(id int) *Hotel {
	for _, v := range hd.Data {
		if v.Id == id {
			return &v
		}
	}
	return nil
}

func (hd *HotelsDataStore) GetHotels() []Hotel {
	return hd.Data
}

func (hd *HotelsDataStore) UpdateHotel(id int, h Hotel)  bool{
	//fmt.Println("222222222")
	
	for i, _ := range hd.Data {
		if hd.Data[i].Id == id {
			hd.Data[i] = h
			return true
		}
	}
	
	return false
}

// func (hd *HotelsDataStore) DeleteHotel(id int) bool {
// 	NewData :=make([]Hotel,0,100)

// 	for i, _ := range hd.Data {
// 		if hd.Data[i].Id == id {
// 			continue
// 		} else{
// 			NewRepo = append(NewData, hd.Data[i])
// 		}

// 	}
	//hd.Data = NewData


// }
