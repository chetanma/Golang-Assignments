package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	//"encoding/json"
)

func HotelHandler(store HotelStore) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idStr := r.URL.Query().Get("id")
		
		if r.Method == "GET" {
			
			if idStr != "" {
				//fmt.Println("111111111111111")
				id, _ := strconv.Atoi(idStr)
				hotel := store.GetHotel(id)
				if hotel != nil {
					hotelBytes, _ := json.Marshal(hotel)
					fmt.Fprint(w, string(hotelBytes))
				} else {
					fmt.Fprint(w, "OOPS!Hotel not found")
				}
			} else {
				data := store.GetHotels()
				dataBytes, _ := json.Marshal(data)
				fmt.Fprint(w, string(dataBytes))
			}

		}

		if r.Method == "POST" {
			var h Hotel
			
			body,_ := ioutil.ReadAll(r.Body)
			json.Unmarshal(body, &h)
			store.AddHotel(h)
			//fmt.Println(store.GetHotels())
			fmt.Fprint(w, "Hotel added successfully",h)
		}

		if r.Method == "PUT" {
			var h Hotel
			
			body,_ := ioutil.ReadAll(r.Body)
			json.Unmarshal(body, &h)
			id, _ := strconv.Atoi(idStr)
			found := store.UpdateHotel(id,h)
			if found == true {
				fmt.Fprint(w,"hotel updated succesfully")
			} else {
				fmt.Fprint(w,"no hotel with entered id found")
			}

		}
		//check the HTTP method
		//GET or POST Or DELETE or PUT
		//if GET then
		//----//if ID is provided in url param then return that specific hotel. Handle error in case of invalid or unknown id
		//---//If Id is not provided then it means return all the hotels
		//---only user1 should be able to fetch all the data. If user 2 return that you are allowed to get all the hotels
		//if POST
		//---//then accept the hotel object. Append to store. Add a method to interface to AddHotel(Hotel). Handle error for bad input
		//implement delete
		//---only user1 should be able to delete
		//implement put for modify
	}
}
func BasicAuthMiddleWare(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user, pass, ok := r.BasicAuth()
		if !ok || !AuthCheck(user, pass) {
			w.WriteHeader(http.StatusUnauthorized)
			fmt.Fprint(w, "Not Authorized")
			return
		}
		//context := context.WithValue(r.Context(), "authuser", user)
		h(w, r)
	}
}

func main() {
	hStore := NewHotelsDataStore()

	h1 := NewHotel("hotel-one", 1001, "pune")
	h2 := NewHotel("hotel-two", 1002, "mum")
	h3 := NewHotel("hotel-three", 1003, "pune")
	h4 := NewHotel("hotel-four", 1004, "mum")

	hStore.AddHotel(*h1)
	hStore.AddHotel(*h2)
	hStore.AddHotel(*h3)
	hStore.AddHotel(*h4)

	http.HandleFunc("/hotels",BasicAuthMiddleWare(HotelHandler(&hStore)))

	//http.HandleFunc("/hotels", HotelHandler(&hStore))
	fmt.Println("server started-----------")
	http.ListenAndServe(":8081", nil)
}


func AuthCheck(user, pass string) bool {
	if user == "user1" && pass == "pass1" {
		return true
	}

	if user == "user2" && pass == "pass2" {
		return true
	}

	return false
}